#include <windows.h>
#include <iostream>
#include <lm.h>

int main() {
    // Define user details
    const char* username = "newadmin";
    const char* password = "Password123!";
    const char* fullName = "New Admin User";

    // Create a new local user account
    USER_INFO_1 ui;
    ZeroMemory(&ui, sizeof(ui));

    ui.usri1_name = (LPWSTR)username;
    ui.usri1_password = (LPWSTR)password;
    ui.usri1_priv = USER_PRIV_USER;
    ui.usri1_home_dir = NULL;
    ui.usri1_comment = (LPWSTR)fullName;

    NET_API_STATUS status = NetUserAdd(NULL, 1, (LPBYTE)&ui, NULL);
    if (status == NERR_Success) {
        std::cout << "User created successfully!" << std::endl;
    } else {
        std::cerr << "Error creating user: " << status << std::endl;
        return 1;
    }

    // Add the new user to the Administrators group
    LOCALGROUP_MEMBERS_INFO_3 member;
    member.lgrmi3_domainandname = (LPWSTR)username;

    status = NetLocalGroupAddMembers(NULL, L"Administrators", 3, (LPBYTE)&member, 1);
    if (status == NERR_Success) {
        std::cout << "User added to Administrators group!" << std::endl;
    } else {
        std::cerr << "Error adding user to Administrators group: " << status << std::endl;
        return 1;
    }

    return 0;
}
